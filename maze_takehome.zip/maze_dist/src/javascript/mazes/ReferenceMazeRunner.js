class Runner {
    constructor() {
        this.name = 'Example Runner'
    }
    run(start, end) {
        return ["North", "East"];
    }
}

module.exports = Runner;